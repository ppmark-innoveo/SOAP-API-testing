var componentForm = undefined;
var autocomplete = undefined;

$(function () {
    autocomplete = undefined;
    componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
    };
    LAB.script("https://maps.googleapis.com/maps/api/js?key=AIzaSyCrkT3Z4vp_EKhzXpRyaHaC5HWe77UNSW8&libraries=places&callback=initAutocomplete")
        .wait(function () {
          
            $(document).on('processInit.skye  postFormUpdate.skye', function (event) {
                initAutocomplete();
            });

       
            geolocate();
            // initAutocomplete();
        });
});

function initAutocomplete() {
    // Create the autocomplete object, restricting the search to geographical
    // location types.
	
	 var options = {
  types: ['geocode'],
  componentRestrictions: {country: ["AE","HU"]} // limits the search result to certain countries
 };
	
    autocomplete = new google.maps.places.Autocomplete(
    (document.getElementById('Travel-Product-googlePlaceApiSearchInput')),options);
  

    // When the user selects an address from the dropdown, populate the address
    // fields in the form.
     autocomplete.addListener('place_changed', fillInAddress);
    // autocomplete2.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
  // Get the place details from the autocomplete object.
  var place = autocomplete.getPlace();
  
 
  console.log(place);
  
	//the fields need to be cleared, because the result might not contains that type of information
    var field=document.getElementById("Travel-Product-parsedCountry");
    field.value  = '';
	field=document.getElementById("Travel-Product-parsedCity"); 
	field.value  = '';
	field=document.getElementById("Travel-Product-parsedStreet");
	field.value  = '';	
  
  // Get each component of the address from the place details,
  // and then fill-in the corresponding field on the form.
	var street='';
	var house_number='';
	var premise=''; // premise indicates a named location, usually a building or collection of buildings with a common name
  for (var i = 0; i < place.address_components.length; i++) {
    var addressType = place.address_components[i].types[0];
	
    if (addressType==='country') {
      var val = place.address_components[i]['long_name'];
	  // console.log('country value: ');
	 //  console.log(val);	   
	    var field=document.getElementById("Travel-Product-parsedCountry");
	//  console.log(field);    
	  field.value  = val; 	 
    }
	 if (addressType==='locality') {
      var val = place.address_components[i]['long_name'];
	   //console.log('city value: ');
	  // console.log(val);	   
	    var field=document.getElementById("Travel-Product-parsedCity");
	 // console.log(field);    
	  field.value  = val; 	 
    }
	 if (addressType==='route') {
      var val = place.address_components[i]['long_name'];
	   //console.log('street value: ');
	   //console.log(val);	   
	    var field=document.getElementById("Travel-Product-parsedStreet");
	 // console.log(field);    
	  field.value  = val; 	 
	  street=val;
    }
	 if (addressType==='street_number') {
      var val = place.address_components[i]['long_name'];
	  // console.log('street_number value: ');
	  // console.log(val);	   
	  
	  //console.log(field);    
	 house_number = val; 	 
    }
	 if (addressType==='premise') {
      var val = place.address_components[i]['long_name'];
	   //console.log('premise value: ');
	   //console.log(val);	   
	  
	  //console.log(field);    
	 premise = val; 	 
    }	
	
  } 
  
	console.log('Street:'+ street);
	console.log('house number:'+ house_number);
	if(house_number!='' && street!='')
	{
		var field=document.getElementById("Travel-Product-parsedStreet");
		field.value=street+' '+house_number;
	}
	else if(premise!='')
	{
		var field=document.getElementById("Travel-Product-parsedStreet");
		field.value=premise;
	}
}

function geolocate() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var geolocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
                center: geolocation,
                radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
        });
    }
}

